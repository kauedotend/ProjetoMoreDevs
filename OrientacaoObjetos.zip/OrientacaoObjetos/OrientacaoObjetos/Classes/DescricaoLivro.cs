﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrientacaoObjetos.Classes
{
    internal class DescricaoLivro
    {

        public string TituloLivro { get; set; }

        public string AutorLivro { get; set;}
     
        

        public void Ler()
        {
            Console.WriteLine($"Estou lendo {TituloLivro} escrito por {AutorLivro}");
        }

    }
}
