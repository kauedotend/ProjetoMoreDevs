﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrientacaoObjetos.Classes
{
    public class ClasseAnimal
    {

        public string NomeAnimal { get; set; }

        public string NomeCientifico { get; set; }

        public int IdadeAnimal { get; set; }


        public void Movimento()
        {
            Console.WriteLine($"{NomeAnimal} de {IdadeAnimal} anos está se movendo!");
        }

    }
}
