﻿

using OrientacaoObjetos.Classes;

//var hb20 = new Carro();

//hb20.Marca = "Hyundai";
//hb20.Modelo = "HB20";
//hb20.Ano = 2012;

//var corsa = new Carro();

//corsa.Marca = "Chevrolett";
//corsa.Modelo = "Corsa";
//corsa.Ano = 1998;


//hb20.Acelerar(200);
//corsa.Acelerar(200);


var galinha = new ClasseAnimal();

galinha.NomeAnimal = "Gertrudes";
galinha.NomeCientifico = "Gallus gallus domesticus";
galinha.IdadeAnimal = 7;

galinha.Movimento();

var livroFavorito = new DescricaoLivro();

livroFavorito.TituloLivro = "O Nome do Vento";
livroFavorito.AutorLivro = "Patrick Rothfuss";

livroFavorito.Ler();











