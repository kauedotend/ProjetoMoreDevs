﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrientacaoObjetos
{
    internal class Calculadora
    {
        public void Somar()
        {

        }
        public void Subtrair()
        {

        }
        public void Multiplicar()
        {

        }
        public void Dividir()
        {

        }
    }
}
